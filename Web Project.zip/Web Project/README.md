# Bitbash  Full-Stack Job Listing Web App

Author: Muhammad Behram Hassan 
Email: muhammadbehramhassan@gmail.com  
Date: October 2025  

##  Overview

This is my submission for the Bitbash Full-Stack Developer take-home project.  
It’s a job-listing web app built with Flask (Python) for the backend and React (JavaScript) for the frontend.

Key features:
 RESTful API with CRUD operations for job listings  
 Filter and sort jobs by type, tags, and posting date  
 Selenium scraper to fetch jobs from *actuarylist.com*  
 Frontend interface for listing, adding, editing, and deleting jobs  
 Proper duplicate-checking on scraped jobs  
 Clean responsive UI with smooth UX
## Tech Stack

  Backend   Python, Flask, SQLAlchemy 
  Database  SQLite (can switch to PostgreSQL/MySQL via `config.py`) 
  Frontend  React (Vite or Create React App) 
  Scraping  Selenium + BeautifulSoup 
  Styling   TailwindCSS 
  Environment   `config.py` for configs  


