import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from sqlalchemy import create_engine

BASE_URL = "https://www.actuarylist.com"

# Database config
DB_USER = "postgres"
DB_PASS = "1234"
DB_HOST = "localhost"
DB_PORT = "5432"
DB_NAME = "myapp"
TABLE_NAME = "Job3"

# Setup Chrome options
options = Options()
options.add_argument("--headless")
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_argument("--window-size=1920,1080")
options.add_argument(
    "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

print("[SCRAPER] Initializing Chrome WebDriver...")
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# PostgreSQL connection
engine = create_engine(f"postgresql+pg8000://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

# -------------------------------------
# Extract jobs from one page
# -------------------------------------
def extract_jobs_from_page():
    jobs = []
    articles = driver.find_elements(By.CSS_SELECTOR, "section.section article")
    print(f"[SCRAPER] Found {len(articles)} jobs on this page")

    for article in articles:
        try:
            job_card = article.find_element(By.CSS_SELECTOR, "div.Job_job-card__YgDAV")
            data = {}

            # Company
            try:
                data["company"] = job_card.find_element(By.CSS_SELECTOR, "p.Job_job-card__company__7T9qY").text.strip()
            except:
                data["company"] = "N/A"

            # Title
            try:
                data["title"] = job_card.find_element(By.CSS_SELECTOR, "p.Job_job-card__position__ic1rc").text.strip()
            except:
                data["title"] = "N/A"

            # Job URL
            try:
                link = article.find_element(By.CSS_SELECTOR, "a.Job_job-page-link__a5I5g")
                href = link.get_attribute("href")
                data["job_url"] = href if href.startswith("http") else BASE_URL + href
            except:
                data["job_url"] = "N/A"

            # Locations / country / salary
            try:
                locations_div = job_card.find_element(By.CSS_SELECTOR, "div.Job_job-card__locations__x1exr")
                try:
                    data["country"] = locations_div.find_element(By.CSS_SELECTOR, "a.Job_job-card__country__GRVhK").text.strip()
                except:
                    data["country"] = "N/A"

                try:
                    data["salary"] = locations_div.find_element(By.CSS_SELECTOR, "p.Job_job-card__salary__QZswp").text.strip()
                except:
                    data["salary"] = "N/A"

                try:
                    all_links = locations_div.find_elements(By.CSS_SELECTOR, "a.Job_job-card__location__bq7jX")
                    locations = [l.text.strip().replace("🏠 ", "") for l in all_links if l.text.strip()]
                    data["locations"] = ", ".join(locations) if locations else "N/A"
                except:
                    data["locations"] = "N/A"
            except:
                data["country"] = "N/A"
                data["salary"] = "N/A"
                data["locations"] = "N/A"

            # Tags
            try:
                tags_div = job_card.find_element(By.CSS_SELECTOR, "div.Job_job-card__tags__zfriA")
                tags = [tag.text.strip() for tag in tags_div.find_elements(By.CSS_SELECTOR, "a") if tag.text.strip()]
                data["tags"] = ", ".join(tags) if tags else "N/A"
            except:
                data["tags"] = "N/A"

            # Posted date
            try:
                data["posted"] = job_card.find_element(By.CSS_SELECTOR, "p.Job_job-card__posted-on__NCZaJ").text.strip()
            except:
                data["posted"] = "N/A"

            jobs.append(data)
        except Exception:
            continue

    return jobs

# -------------------------------------
# Save page data (DB + CSV)
# -------------------------------------
def save_page_data(jobs, page_number):
    if not jobs:
        print(f"[SCRAPER] No jobs found on page {page_number}")
        return

    df = pd.DataFrame(jobs)
    columns_order = ["title", "company", "country", "locations", "salary", "tags", "posted", "job_url"]
    df = df[columns_order]

    csv_file = "jobs_incremental.csv"
    df.to_csv(csv_file, mode='a', header=not pd.io.common.file_exists(csv_file), index=False, encoding="utf-8-sig")

    df.to_sql(TABLE_NAME, engine, if_exists="append", index=False)

    print(f"[SCRAPER] Page {page_number}: {len(df)} jobs saved to DB & CSV.")


# -------------------------------------
# Main Scraper Logic
# -------------------------------------
try:
    print(f"[SCRAPER] Loading main page: {BASE_URL}")
    driver.get(BASE_URL)
    time.sleep(8)

    page = 1
    max_pages = 50

    while page <= max_pages:
        print(f"[SCRAPER] Scraping page {page}...")
        page_jobs = extract_jobs_from_page()
        save_page_data(page_jobs, page)

        try:
            next_button = driver.find_element(By.XPATH, "//a[contains(text(), 'Next')] | //button[contains(text(), 'Next')] | //a[@rel='next']")
            if next_button.is_enabled():
                next_button.click()
                page += 1
                time.sleep(5)
            else:
                print("[SCRAPER] No more pages available.")
                break
        except:
            print("[SCRAPER] No 'Next' button found — reached last page.")
            break

    print("[SCRAPER] Scraping completed successfully.")

except Exception as e:
    print(f"[SCRAPER] Critical Error: {str(e)}")
    import traceback
    traceback.print_exc()

finally:
    print("[SCRAPER] Closing browser...")
    driver.quit()
    print("[SCRAPER] Done.")
