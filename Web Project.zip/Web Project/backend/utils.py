Flask==2.3.5
Flask-SQLAlchemy==3.0.5
psycopg2-binary==2.9.9
selenium==5.9.1
webdriver-manager==3.8.6
