# models.py
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Job(db.Model):
    __tablename__ = "Job1"  # Match your existing table name

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(255))
    company = db.Column(db.String(255))
    country = db.Column(db.String(255))
    locations = db.Column(db.String(255))
    salary = db.Column(db.String(255))
    tags = db.Column(db.String(255))
    posted = db.Column(db.String(255))
    job_url = db.Column(db.String(500), unique=True)

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "company": self.company,
            "country": self.country,
            "locations": self.locations,
            "salary": self.salary,
            "tags": self.tags,
            "posted": self.posted,
            "job_url": self.job_url,
        }
