from flask import Flask
from flask_cors import CORS  #Import CORS
from config import SQLALCHEMY_DATABASE_URI, SQLALCHEMY_TRACK_MODIFICATIONS
from models import db
from routes import routes

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = SQLALCHEMY_DATABASE_URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = SQLALCHEMY_TRACK_MODIFICATIONS

db.init_app(app)
app.register_blueprint(routes)

#  Enable CORS for all routes (for development)
CORS(app)  # You can later restrict origins for production

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    print(" Backend running at http://localhost:5000")
    app.run(debug=True)
