from flask import Blueprint, jsonify, request
from models import db, Job
from sqlalchemy import or_
import threading
import subprocess
import sys
import os
import io

# Ensure UTF-8 output (especially for Windows console)
if sys.stdout.encoding is None or sys.stdout.encoding.lower() != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

routes = Blueprint("routes", __name__)

# ----------------- CRUD ROUTES -----------------
@routes.route("/api/jobs", methods=["GET"])
def get_jobs():
    keyword = request.args.get("keyword", "")
    country = request.args.get("country", "")
    tag = request.args.get("tag", "")
    sort = request.args.get("sort", "posting_date_desc")

    page = int(request.args.get("page", 1))
    limit = int(request.args.get("limit", 15))
    offset = (page - 1) * limit

    query = Job.query

    # 🔍 Keyword search
    if keyword:
        query = query.filter(
            or_(
                Job.title.ilike(f"%{keyword}%"),
                Job.company.ilike(f"%{keyword}%"),
            )
        )

    # 🌍 Country filter (emoji + text tolerant)
    if country:
        # Support multiple countries
        country_list = [c.strip().lower() for c in country.split(",") if c.strip()]

        # SQLAlchemy does not strip emojis, so we normalize country text on the fly
        # We use LIKE matches for both emoji & plain names
        conditions = []
        for c in country_list:
            # Try to match with emoji, or plain text like "USA", "United States", etc.
            conditions.append(Job.country.ilike(f"%{c}%"))
            conditions.append(Job.country.ilike(f"%🇺🇸 {c}%"))
            conditions.append(Job.country.ilike(f"%{c.upper()}%"))
            conditions.append(Job.country.ilike(f"%{c.capitalize()}%"))
        query = query.filter(or_(*conditions))

    # 🏷️ Tag filter
    if tag:
        query = query.filter(Job.tags.ilike(f"%{tag}%"))

    # 🔢 Sorting
    sort_map = {
        "posting_date_desc": Job.posted.desc(),
        "posting_date_asc": Job.posted.asc(),
        "company_asc": Job.company.asc(),
        "company_desc": Job.company.desc(),
        "title_asc": Job.title.asc(),
        "title_desc": Job.title.desc(),
    }
    if sort in sort_map:
        query = query.order_by(sort_map[sort])

    total_jobs = query.count()
    jobs = query.offset(offset).limit(limit).all()

    return jsonify({
        "jobs": [job.to_dict() for job in jobs],
        "total": total_jobs,
        "page": page,
        "limit": limit
    })

@routes.route("/api/jobs/<int:job_id>", methods=["GET"])
def get_job(job_id):
    job = Job.query.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(job.to_dict())


@routes.route("/api/jobs", methods=["POST"])
def create_job():
    data = request.get_json()
    if not data.get("title") or not data.get("company") or not data.get("job_url"):
        return jsonify({"error": "title, company, and job_url required"}), 400

    if Job.query.filter_by(job_url=data["job_url"]).first():
        return jsonify({"error": "Job already exists"}), 400

    job = Job(**data)
    db.session.add(job)
    db.session.commit()
    return jsonify(job.to_dict()), 201


@routes.route("/api/jobs/<int:job_id>", methods=["PUT", "PATCH"])
def update_job(job_id):
    job = Job.query.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404

    data = request.get_json()
    allowed_fields = [
        "title", "company", "country", "locations", "salary",
        "tags", "posted", "job_url"
    ]

    for field in allowed_fields:
        if field in data:
            setattr(job, field, data[field])

    db.session.commit()
    return jsonify(job.to_dict())


@routes.route("/api/jobs/<int:job_id>", methods=["DELETE"])
def delete_job(job_id):
    job = Job.query.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404

    db.session.delete(job)
    db.session.commit()
    return jsonify({"message": "Job deleted"})


# ----------------- SCRAPER TRIGGER -----------------
@routes.route("/api/jobs/scrape", methods=["POST"])
def scrape_jobs_route():
    """Run scraper.py in a background thread with real-time logs."""

    def run_scraper():
        print("\n--- Starting background scraper.py ---\n", flush=True)
        try:
            script_path = os.path.join(os.getcwd(), "scraper.py")

            process = subprocess.Popen(
                [sys.executable, "-u", script_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1
            )

            for line in iter(process.stdout.readline, ""):
                if line.strip():
                    print(f"[SCRAPER] {line.strip()}", flush=True)

            process.stdout.close()
            process.wait()

            print(f"\n--- Scraper exited with code {process.returncode} ---\n", flush=True)

        except Exception as ex:
            print(f"[ERROR] Scraper thread failed: {ex}", flush=True)
        finally:
            print("--- Background scraper thread completed ---\n", flush=True)

    threading.Thread(target=run_scraper, daemon=True).start()
    return jsonify({"message": "Scraper started in background"})
